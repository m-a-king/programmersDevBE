package day02.library;

public interface Borrowable {
    public void borrow(int memberId, String title);
}
